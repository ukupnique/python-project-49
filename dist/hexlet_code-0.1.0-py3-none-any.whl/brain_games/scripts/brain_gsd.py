#!/usr/bin/env python3

from brain_games.games.gsd import brain_gsd


def main():
    brain_gsd()


if __name__ == "__main__":
    main()

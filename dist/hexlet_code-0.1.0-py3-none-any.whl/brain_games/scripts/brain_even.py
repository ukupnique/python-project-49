import prompt, random


def brain_even():
    print("Welcome to the Brain Games!")
    name = prompt.string("May I have your name? ")
    print(f"Hello, {name}!")
    true_answer= 0
    print('Answer "yes" if the number is even, otherwise answer "no".')
    while true_answer < 3:
        number = random.randint(0, 1000)
        print(f'Question: {number}')
        answ = prompt.string("Your answer: ")
        if answ == 'yes' and number%2 == 0 or answ == 'no' and number%2 != 0:
            print('Correct!')
            true_answer += 1
        else:
            if answ == 'yes' and number % 2 != 0:
                print(f"'yes' is wrong answer ;(. Correct answer was 'no'.")
                break
            elif answ == 'no' and number%2 != 0:
                print(f"'no' is wrong answer ;(. Correct answer was 'yes'.")
                break
            else:
                res = 'yes' if number%2 == 0 else 'no'
                print(f"'{answ}' is wrong answer ;(. Correct answer was '{res}'.")
                break
    if true_answer == 3:
        print(f'Congratulations, {name}!')
    else:
        print(f"Let's try again, {name}!")

def main():
    brain_even()

if __name__ == "__main__":
    main()

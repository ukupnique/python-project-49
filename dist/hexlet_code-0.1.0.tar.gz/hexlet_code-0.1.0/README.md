### Hexlet tests and linter status:
[![Actions Status](https://github.com/ukupnique/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ukupnique/python-project-49/actions)

### Maintainability 
[![Maintainability](https://api.codeclimate.com/v1/badges/3bb09de06a71a4c624af/maintainability)](https://codeclimate.com/github/ukupnique/python-project-49/maintainability)
